var searchData=
[
  ['name_0',['Name',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_named.html#a7c41bf52c9482f6e56c27fd0d7d28fa8',1,'Point85::ShiftSharp::Schedule::Named']]],
  ['named_1',['Named',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_named.html',1,'Point85.ShiftSharp.Schedule.Named'],['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_named.html#ac2713622e23f83520f776c061d945a7e',1,'Point85.ShiftSharp.Schedule.Named.Named()']]],
  ['nonworkingperiod_2',['NonWorkingPeriod',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_non_working_period.html',1,'Point85.ShiftSharp.Schedule.NonWorkingPeriod'],['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_non_working_period.html#a2b587552a92a99170eb1daa3ad8ab635',1,'Point85.ShiftSharp.Schedule.NonWorkingPeriod.NonWorkingPeriod()']]],
  ['nonworkingperiods_3',['NonWorkingPeriods',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_work_schedule.html#a3f9e8d23875ddd44701523245cd880c3',1,'Point85::ShiftSharp::Schedule::WorkSchedule']]]
];
