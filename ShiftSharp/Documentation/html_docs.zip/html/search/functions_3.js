var searchData=
[
  ['deletenonworkingperiod_0',['DeleteNonWorkingPeriod',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_work_schedule.html#aa4feb3d07595ed923228182389c47e2e',1,'Point85::ShiftSharp::Schedule::WorkSchedule']]],
  ['deleteshift_1',['DeleteShift',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_work_schedule.html#a419aaaed2d9c45d38981c38c61fc97d4',1,'Point85::ShiftSharp::Schedule::WorkSchedule']]],
  ['deleteteam_2',['DeleteTeam',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_work_schedule.html#a0a2ad0076c8a226916f66b057e7eada5',1,'Point85::ShiftSharp::Schedule::WorkSchedule']]],
  ['deltadays_3',['DeltaDays',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_time_period.html#aaa5abdde276981c0ae25250e3a2ae93e',1,'Point85::ShiftSharp::Schedule::TimePeriod']]]
];
