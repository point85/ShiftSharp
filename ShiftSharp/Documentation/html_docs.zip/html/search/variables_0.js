var searchData=
[
  ['duration_0',['Duration',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_non_working_period.html#ac4e5a83e0de506d2e6b8b8fb736219db',1,'Point85::ShiftSharp::Schedule::NonWorkingPeriod']]]
];
