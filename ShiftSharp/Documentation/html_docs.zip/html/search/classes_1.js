var searchData=
[
  ['named_0',['Named',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_named.html',1,'Point85::ShiftSharp::Schedule']]],
  ['nonworkingperiod_1',['NonWorkingPeriod',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_non_working_period.html',1,'Point85::ShiftSharp::Schedule']]]
];
