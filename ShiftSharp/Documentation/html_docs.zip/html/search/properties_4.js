var searchData=
[
  ['name_0',['Name',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_named.html#a7c41bf52c9482f6e56c27fd0d7d28fa8',1,'Point85::ShiftSharp::Schedule::Named']]],
  ['nonworkingperiods_1',['NonWorkingPeriods',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_work_schedule.html#a3f9e8d23875ddd44701523245cd880c3',1,'Point85::ShiftSharp::Schedule::WorkSchedule']]]
];
