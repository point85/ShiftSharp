var searchData=
[
  ['workschedule_0',['WorkSchedule',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_work_schedule.html#abaa4d3a1ac08d93b599a209a31f3ec8b',1,'Point85.ShiftSharp.Schedule.WorkSchedule.WorkSchedule()'],['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_work_schedule.html#a7f38b8cecb384efd9308c80d77f692cd',1,'Point85.ShiftSharp.Schedule.WorkSchedule.WorkSchedule(string name, string description)']]]
];
