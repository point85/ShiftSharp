var searchData=
[
  ['team_0',['Team',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_shift_instance.html#a7ea935c9ee1bae00dd79df328850d636',1,'Point85::ShiftSharp::Schedule::ShiftInstance']]],
  ['teams_1',['Teams',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_work_schedule.html#a8602626131a018c5ee98b830c54ca2de',1,'Point85::ShiftSharp::Schedule::WorkSchedule']]]
];
