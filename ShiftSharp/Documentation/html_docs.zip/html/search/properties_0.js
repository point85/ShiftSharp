var searchData=
[
  ['breaks_0',['Breaks',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_shift.html#ae465ecdf0cc52998b1dcecee99d0913f',1,'Point85::ShiftSharp::Schedule::Shift']]]
];
