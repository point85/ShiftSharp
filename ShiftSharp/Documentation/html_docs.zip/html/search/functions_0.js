var searchData=
[
  ['addbreak_0',['AddBreak',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_shift.html#accfe537265e0471e00a3aff48a745663',1,'Point85::ShiftSharp::Schedule::Shift']]],
  ['addmember_1',['AddMember',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_team.html#ab153e78d0337afa44290dac050e9a2ff',1,'Point85::ShiftSharp::Schedule::Team']]],
  ['addmemberexception_2',['AddMemberException',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_team.html#a1628bc30e68ef2ffedee04c424266a88',1,'Point85::ShiftSharp::Schedule::Team']]],
  ['addsegment_3',['AddSegment',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_rotation.html#ab1ebe10b2fa166f10be1e431e1cf7768',1,'Point85::ShiftSharp::Schedule::Rotation']]]
];
