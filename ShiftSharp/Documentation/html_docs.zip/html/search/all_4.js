var searchData=
[
  ['equals_0',['Equals',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_named.html#a53f11a59f074b34a2676eda736d9a2bb',1,'Point85.ShiftSharp.Schedule.Named.Equals()'],['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_team_member.html#a27a49fb290fa655aeff13f278c8076a4',1,'Point85.ShiftSharp.Schedule.TeamMember.Equals()']]]
];
