var searchData=
[
  ['addbreak_0',['AddBreak',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_shift.html#accfe537265e0471e00a3aff48a745663',1,'Point85::ShiftSharp::Schedule::Shift']]],
  ['addsegment_1',['AddSegment',['../class_point85_1_1_shift_sharp_1_1_schedule_1_1_rotation.html#ab1ebe10b2fa166f10be1e431e1cf7768',1,'Point85::ShiftSharp::Schedule::Rotation']]]
];
