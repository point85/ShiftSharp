$doxydocs=
{
  classes => [
    {
      name => 'Point85::ShiftSharp::Schedule::Break',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.TimePeriod',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'Break',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Break'
        },
        {
          name => 'DeltaDays',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Duration',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetEnd',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'IsWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Break'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'SecondOfDay',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'StartTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'TimePeriod',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'TimePeriod',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'Break',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Break constructor. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name of break'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Description of break'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'start'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Start time of break'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'duration'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Duration of break'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              },
              {
                declaration_name => 'start',
                type => 'LocalTime'
              },
              {
                declaration_name => 'duration',
                type => 'Duration'
              }
            ]
          },
          {
            kind => 'function',
            name => 'IsWorkingPeriod',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'A break is a working period. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True'
                    }
                  ]
                }
              ]
            },
            type => 'override bool',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class Break is a defined working period of time during a shift, for example lunch. '
          }
        ]
      },
      detailed => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'linebreak'
          },
          {
            type => 'text',
            content => ' '
          }
        ]
      }
    },
    {
      name => 'Point85::ShiftSharp::Schedule::DayOff',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.TimePeriod',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'DayOff',
          virtualness => 'non_virtual',
          protection => 'package',
          scope => 'Point85::ShiftSharp::Schedule::DayOff'
        },
        {
          name => 'DeltaDays',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Duration',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetEnd',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'IsWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::DayOff'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'SecondOfDay',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'StartTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'TimePeriod',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'TimePeriod',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'IsWorkingPeriod',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'A DayOff is not a working period. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'False'
                    }
                  ]
                }
              ]
            },
            type => 'override bool',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class DayOff represents a scheduled non-working period. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'IComparable',
      kind => 'class',
      derived => [
        {
          name => 'Point85.ShiftSharp.Schedule.NonWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.Rotation',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.RotationSegment',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.Shift',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.ShiftInstance',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.Team',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.TeamMember',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::Named',
      kind => 'class',
      derived => [
        {
          name => 'Point85.ShiftSharp.Schedule.NonWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.Rotation',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.Team',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.TeamMember',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.TimePeriod',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.WorkSchedule',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'Equals',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Check for equality. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'other Quantity'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True if equal'
                    }
                  ]
                }
              ]
            },
            type => 'override bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'Object'
              }
            ]
          },
          {
            kind => 'function',
            name => 'GetHashCode',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compute a hash code. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Hash code'
                    }
                  ]
                }
              ]
            },
            type => 'override int',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get a string representation of a named object. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'String value'
                    }
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'Name',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'name '
                }
              ]
            },
            detailed => {},
            type => 'string'
          },
          {
            kind => 'property',
            name => 'Description',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'description '
                }
              ]
            },
            detailed => {},
            type => 'string'
          }
        ]
      },
      protected_methods => {
        members => [
          {
            kind => 'function',
            name => 'Named',
            virtualness => 'non_virtual',
            protection => 'protected',
            static => 'no',
            brief => {},
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'Named',
            virtualness => 'non_virtual',
            protection => 'protected',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Description'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              }
            ]
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class Named represents a named object such as a Shift or Team. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.Named',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'IComparable',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'CompareTo',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Duration',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetEndDateTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'IsInPeriod',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'NonWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'NonWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'package',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'StartDateTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'WorkSchedule',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'NonWorkingPeriod',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetEndDateTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get period end date and time. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Period end'
                    }
                  ]
                }
              ]
            },
            type => 'LocalDateTime',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a string representation of this non-working period. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'CompareTo',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compare this non-working period to another such period by start date and time of day. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Non-working period'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'negative if less than, 0 if equal and positive if greater than'
                    }
                  ]
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'NonWorkingPeriod'
              }
            ]
          },
          {
            kind => 'function',
            name => 'IsInPeriod',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Check to see if this day is contained in the non-working period. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'day'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Date to check'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True if in the non-working period'
                    }
                  ]
                }
              ]
            },
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'day',
                type => 'LocalDate'
              }
            ]
          }
        ]
      },
      public_members => {
        members => [
          {
            kind => 'variable',
            name => 'Duration',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'duration of period '
                }
              ]
            },
            detailed => {},
            type => 'Duration'
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'WorkSchedule',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'owning work schedule '
                }
              ]
            },
            detailed => {},
            type => 'WorkSchedule'
          },
          {
            kind => 'property',
            name => 'StartDateTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'starting date and time of day '
                }
              ]
            },
            detailed => {},
            type => 'LocalDateTime'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class NonWorkingPeriod represents named non-working, non-recurring periods. '
          },
          {
            type => 'linebreak'
          },
          {
            type => 'text',
            content => ' For example holidays and scheduled outages such as for preventive maintenance. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::Rotation',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.Named',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'IComparable',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'AddSegment',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'CompareTo',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'DAY_OFF',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'DAY_OFF_NAME',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetDayCount',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'GetDuration',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetPeriods',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'GetWorkingTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'periods',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'Rotation',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'Rotation',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'Rotation',
          virtualness => 'non_virtual',
          protection => 'package',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'RotationSegments',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'WorkSchedule',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Rotation'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'Rotation',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'default constructor '
                }
              ]
            },
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetPeriods',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'get the shifts and off-shifts in the rotation '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'List of time periods'
                    }
                  ]
                }
              ]
            },
            type => 'List< TimePeriod >',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetDayCount',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the number of days in the rotation. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                  ]
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetDuration',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the duration of this rotation. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetWorkingTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the shift rotation\'s total working time. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'AddSegment',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Add a working period to this rotation. A working period starts with a shift and specifies the number of days on and days off. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'startingShift'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Starting shift of rotation'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'daysOn'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Number of day on shift'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'daysOff'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Number of days off shift'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Part of the rotation'
                    }
                  ]
                }
              ]
            },
            type => 'RotationSegment',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'startingShift',
                type => 'Shift'
              },
              {
                declaration_name => 'daysOn',
                type => 'int'
              },
              {
                declaration_name => 'daysOff',
                type => 'int'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CompareTo',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compare thsi rotation to another rotation. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Other rotation'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                  ]
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'Rotation'
              }
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a string representation of this rotation. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'String'
                    }
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'WorkSchedule',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'owning work schedule '
                }
              ]
            },
            detailed => {},
            type => 'WorkSchedule'
          },
          {
            kind => 'property',
            name => 'RotationSegments',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'working periods in the rotation '
                }
              ]
            },
            detailed => {},
            type => 'List< RotationSegment >',
            initializer => '= new List<RotationSegment>()'
          }
        ]
      },
      private_members => {
        members => [
          {
            kind => 'variable',
            name => 'periods',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'list of working and non-working days '
                }
              ]
            },
            detailed => {},
            type => 'List< TimePeriod >'
          }
        ]
      },
      private_static_methods => {
        members => [
          {
            kind => 'function',
            name => 'Rotation',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'yes',
            brief => {},
            detailed => {},
            type => 'static',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      private_static_members => {
        members => [
          {
            kind => 'variable',
            name => 'DAY_OFF_NAME',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'yes',
            brief => {},
            detailed => {},
            type => 'const string',
            initializer => '= "DAY_OFF"'
          },
          {
            kind => 'variable',
            name => 'DAY_OFF',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'yes',
            brief => {},
            detailed => {},
            type => 'static DayOff'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class Rotation maintains a sequenced list of shift and off-shift time periods. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::RotationSegment',
      kind => 'class',
      base => [
        {
          name => 'IComparable',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'CompareTo',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::RotationSegment'
        },
        {
          name => 'DaysOff',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::RotationSegment'
        },
        {
          name => 'DaysOn',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::RotationSegment'
        },
        {
          name => 'Rotation',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::RotationSegment'
        },
        {
          name => 'RotationSegment',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::RotationSegment'
        },
        {
          name => 'RotationSegment',
          virtualness => 'non_virtual',
          protection => 'package',
          scope => 'Point85::ShiftSharp::Schedule::RotationSegment'
        },
        {
          name => 'Sequence',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::RotationSegment'
        },
        {
          name => 'StartingShift',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::RotationSegment'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'RotationSegment',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'CompareTo',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compare this rotation segment to. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Other rotation segment'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => '-1 if less than, 0 if equal and 1 if greater than'
                    }
                  ]
                },
                {
                  type => 'linebreak'
                },
                {
                  type => 'text',
                  content => ' '
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'RotationSegment'
              }
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'Rotation',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'parent rotation '
                }
              ]
            },
            detailed => {},
            type => 'Rotation'
          },
          {
            kind => 'property',
            name => 'Sequence',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'ordering within the rotation '
                }
              ]
            },
            detailed => {},
            type => 'int',
            initializer => '= 0'
          },
          {
            kind => 'property',
            name => 'StartingShift',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'shift that starts this segment '
                }
              ]
            },
            detailed => {},
            type => 'Shift'
          },
          {
            kind => 'property',
            name => 'DaysOn',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'number of days on shift '
                }
              ]
            },
            detailed => {},
            type => 'int',
            initializer => '= 0'
          },
          {
            kind => 'property',
            name => 'DaysOff',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'number of days off shift '
                }
              ]
            },
            detailed => {},
            type => 'int',
            initializer => '= 0'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'This class represents part of an entire rotation. The segment starts with a shift and includes a count of the number of days on followed by the number of days off. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::Shift',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.TimePeriod',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'IComparable',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'AddBreak',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'Breaks',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'CalculateBreakTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'CalculateWorkingTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'CalculateWorkingTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'CompareTo',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'CreateBreak',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'DeltaDays',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Duration',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetEnd',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'IsInShift',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'IsWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'RemoveBreak',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'SecondOfDay',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Shift',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'Shift',
          virtualness => 'non_virtual',
          protection => 'package',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'SpansMidnight',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'StartTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'TimePeriod',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'TimePeriod',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'ToRoundedSecond',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'WorkSchedule',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Shift'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'Shift',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'AddBreak',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Add a break period to this shift. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'breakPeriod'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Break'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'breakPeriod',
                type => 'Break'
              }
            ]
          },
          {
            kind => 'function',
            name => 'RemoveBreak',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Remove a break from this shift. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'breakPeriod'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Break'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'breakPeriod',
                type => 'Break'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CreateBreak',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Create a break for this shift. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Description'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'startTime'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Staring time'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'duration'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Duration'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                  ]
                }
              ]
            },
            type => 'Break',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'String'
              },
              {
                declaration_name => 'description',
                type => 'String'
              },
              {
                declaration_name => 'startTime',
                type => 'LocalTime'
              },
              {
                declaration_name => 'duration',
                type => 'Duration'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CalculateWorkingTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Calculate the working time between the specified times of day. The shift must not span midnight. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'from'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Starting local time'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'to'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Ending local time'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'from',
                type => 'LocalTime'
              },
              {
                declaration_name => 'to',
                type => 'LocalTime'
              }
            ]
          },
          {
            kind => 'function',
            name => 'SpansMidnight',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Check to see if this shift crosses midnight. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True if it does'
                    }
                  ]
                }
              ]
            },
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'CalculateWorkingTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Calculate the working time between the specified times of day. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'from'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Starting local time'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'to'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Ending local time'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'beforeMidnight'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'If true, shifts ends before midnight'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'from',
                type => 'LocalTime'
              },
              {
                declaration_name => 'to',
                type => 'LocalTime'
              },
              {
                declaration_name => 'beforeMidnight',
                type => 'bool'
              }
            ]
          },
          {
            kind => 'function',
            name => 'IsInShift',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Test if the specified time falls within the shift. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'time'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Local time'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True if this time is in the shift'
                    }
                  ]
                }
              ]
            },
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'time',
                type => 'LocalTime'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CalculateBreakTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Calculate the total break time for the shift. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Sum of breaks'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'CompareTo',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compare one shift to another one. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Other shift'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => '-1 if less than, 0 if equal and 1 if greater than'
                    }
                  ]
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'Shift'
              }
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a string representation of this shift. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'String'
                    }
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'IsWorkingPeriod',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Shift is a working period. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True'
                    }
                  ]
                }
              ]
            },
            type => 'override bool',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'WorkSchedule',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'owning work schedule '
                }
              ]
            },
            detailed => {},
            type => 'WorkSchedule'
          },
          {
            kind => 'property',
            name => 'Breaks',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'breaks '
                }
              ]
            },
            detailed => {},
            type => 'List< Break >',
            initializer => '= new List<Break>()'
          }
        ]
      },
      private_methods => {
        members => [
          {
            kind => 'function',
            name => 'ToRoundedSecond',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'time',
                type => 'LocalTime'
              }
            ]
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class Shift is a scheduled working time period, and can include breaks. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::ShiftInstance',
      kind => 'class',
      base => [
        {
          name => 'IComparable',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'CompareTo',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        },
        {
          name => 'GetEndTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        },
        {
          name => 'IsInShiftInstance',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        },
        {
          name => 'Shift',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        },
        {
          name => 'ShiftInstance',
          virtualness => 'non_virtual',
          protection => 'package',
          scope => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        },
        {
          name => 'StartDateTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        },
        {
          name => 'Team',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'GetEndTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the end date and time of day. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Ending time'
                    }
                  ]
                }
              ]
            },
            type => 'LocalDateTime',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'CompareTo',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compare this non-working period to another such period by start time of day. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Other shift instance'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => '-1 if less than, 0 if equal and 1 if greater than'
                    }
                  ]
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'ShiftInstance'
              }
            ]
          },
          {
            kind => 'function',
            name => 'IsInShiftInstance',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Determine if this time falls within the shift instance period. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'ldt'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Date and time to check'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True if the specified time is in this shift instance'
                    }
                  ]
                }
              ]
            },
            type => 'Boolean',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'ldt',
                type => 'LocalDateTime'
              }
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a string representation of a shift instance. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'String'
                    }
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'Shift',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'definition of the shift '
                }
              ]
            },
            detailed => {},
            type => 'Shift'
          },
          {
            kind => 'property',
            name => 'Team',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'team working it '
                }
              ]
            },
            detailed => {},
            type => 'Team'
          },
          {
            kind => 'property',
            name => 'StartDateTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'start date and time of day '
                }
              ]
            },
            detailed => {},
            type => 'LocalDateTime'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class ShiftInstance is an instance of a Shift. A shift instance is worked by a Team. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::Team',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.Named',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'IComparable',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'AddMember',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'AddMemberException',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'AssignedMembers',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'BuildMemberCache',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'CalculateWorkingTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'CompareTo',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'ExceptionCache',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'GetDayInRotation',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetHoursWorkedPerWeek',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'GetMembers',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'GetPercentageWorked',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'GetRotationDuration',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'GetShiftInstanceForDay',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'HasMember',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'IsDayOff',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'MemberExceptions',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'removeMember',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'RemoveMemberException',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'Rotation',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'RotationStart',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'Team',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'Team',
          virtualness => 'non_virtual',
          protection => 'package',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'WorkSchedule',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Team'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'Team',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetRotationDuration',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the duration of the shift rotation. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetPercentageWorked',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the shift rotation\'s working time as a percentage of the rotation duration. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Percentage'
                    }
                  ]
                }
              ]
            },
            type => 'float',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetHoursWorkedPerWeek',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the average number of hours worked each week by this team. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetDayInRotation',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the day number in the rotation for this local date. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'date'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Date in rotation'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Day number'
                    }
                  ]
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'date',
                type => 'LocalDate'
              }
            ]
          },
          {
            kind => 'function',
            name => 'GetShiftInstanceForDay',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the ShiftInstance for the specified day. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'day'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Date'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Shift instance'
                    }
                  ]
                }
              ]
            },
            type => 'ShiftInstance',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'day',
                type => 'LocalDate'
              }
            ]
          },
          {
            kind => 'function',
            name => 'IsDayOff',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Check to see if this day is a day off. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'day'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Date'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True if this is a day off'
                    }
                  ]
                }
              ]
            },
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'day',
                type => 'LocalDate'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CalculateWorkingTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Calculate the schedule working time between the specified dates and times. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'from'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Starting date and time'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'to'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Ending date and time'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'from',
                type => 'LocalDateTime'
              },
              {
                declaration_name => 'to',
                type => 'LocalDateTime'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CompareTo',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compare one team to another. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Other team'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => '-1 if less than, 0 if equal and 1 if greater than'
                    }
                  ]
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'Team'
              }
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a string value for this team. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'String'
                    }
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'AddMember',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Add a member to this team. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'member'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Team member'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'member',
                type => 'TeamMember'
              }
            ]
          },
          {
            kind => 'function',
            name => 'removeMember',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Remove a member from this team. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'member'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Team member'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'member',
                type => 'TeamMember'
              }
            ]
          },
          {
            kind => 'function',
            name => 'HasMember',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'True if member is assigned to this team. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'member'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Team member'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'bool'
                    }
                  ]
                }
              ]
            },
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'member',
                type => 'TeamMember'
              }
            ]
          },
          {
            kind => 'function',
            name => 'AddMemberException',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Add a member exception for this team. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'memberException'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Team member exception'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'memberException',
                type => 'TeamMemberException'
              }
            ]
          },
          {
            kind => 'function',
            name => 'RemoveMemberException',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Remove a member exception for this team. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'memberException'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Team member exception'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'memberException',
                type => 'TeamMemberException'
              }
            ]
          },
          {
            kind => 'function',
            name => 'GetMembers',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a list of team member for the specified shift start. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'shiftStart'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Shift instance starting date and time'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'List of team members'
                    }
                  ]
                }
              ]
            },
            type => 'List< TeamMember >',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'shiftStart',
                type => 'LocalDateTime'
              }
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'WorkSchedule',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'owning work schedule '
                }
              ]
            },
            detailed => {},
            type => 'WorkSchedule'
          },
          {
            kind => 'property',
            name => 'RotationStart',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'reference date for starting the rotations '
                }
              ]
            },
            detailed => {},
            type => 'LocalDate'
          },
          {
            kind => 'property',
            name => 'Rotation',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'shift rotation days '
                }
              ]
            },
            detailed => {},
            type => 'Rotation'
          },
          {
            kind => 'property',
            name => 'AssignedMembers',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Team members assigned to work regular shifts. '
                }
              ]
            },
            detailed => {},
            type => 'List< TeamMember >',
            initializer => '= new List<TeamMember>()'
          },
          {
            kind => 'property',
            name => 'MemberExceptions',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Team member exceptions to regular shifts. '
                }
              ]
            },
            detailed => {},
            type => 'List< TeamMemberException >',
            initializer => '= new List<TeamMemberException>()'
          }
        ]
      },
      private_methods => {
        members => [
          {
            kind => 'function',
            name => 'BuildMemberCache',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      private_members => {
        members => [
          {
            kind => 'variable',
            name => 'ExceptionCache',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'ConcurrentDictionary< LocalDateTime, TeamMemberException >'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class Team is a named group of individuals who rotate through a shift schedule. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::TeamMember',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.Named',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'IComparable',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'CompareTo',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMember'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMember'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMember'
        },
        {
          name => 'MemberID',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMember'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'TeamMember',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMember'
        },
        {
          name => 'TeamMember',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMember'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMember'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'TeamMember',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'TeamMember',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor with id. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Member name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Member description, e.g. title'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'id'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Member ID, e.g. employee ID'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              },
              {
                declaration_name => 'id',
                type => 'string'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CompareTo',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compare one team member to another. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Other team member'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => '-1 if less than, 0 if equal and 1 if greater than'
                    }
                  ]
                }
              ]
            },
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'TeamMember'
              }
            ]
          },
          {
            kind => 'function',
            name => 'Equals',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Check for equality. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'other'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'other Quantity'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True if equal'
                    }
                  ]
                }
              ]
            },
            type => 'override bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'Object'
              }
            ]
          },
          {
            kind => 'function',
            name => 'GetHashCode',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Compute a hash code. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Hash code'
                    }
                  ]
                }
              ]
            },
            type => 'override int',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a string value for this team member. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'String'
                    }
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'MemberID',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Identifier of the team member, e.g. employee ID. '
                }
              ]
            },
            detailed => {},
            type => 'string'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class TeamMember represents a person assigned to a Team. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::TeamMemberException',
      kind => 'class',
      inner => [
      ],
      all_members => [
        {
          name => 'Addition',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMemberException'
        },
        {
          name => 'DateTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMemberException'
        },
        {
          name => 'Reason',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMemberException'
        },
        {
          name => 'Removal',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMemberException'
        },
        {
          name => 'TeamMemberException',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TeamMemberException'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'TeamMemberException',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Construct an exception for the shift instance at this starting date and time. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'dateTime'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Shift instance starting date and time'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'dateTime',
                type => 'LocalDateTime'
              }
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'DateTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'start date and time of day of the shift '
                }
              ]
            },
            detailed => {},
            type => 'LocalDateTime'
          },
          {
            kind => 'property',
            name => 'Reason',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'reason for the change '
                }
              ]
            },
            detailed => {},
            type => 'string'
          },
          {
            kind => 'property',
            name => 'Addition',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'team member to add '
                }
              ]
            },
            detailed => {},
            type => 'TeamMember'
          },
          {
            kind => 'property',
            name => 'Removal',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'team member to remove '
                }
              ]
            },
            detailed => {},
            type => 'TeamMember'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'This class provides information for adding or removing a team member for a team working an instance of a shift. The shift instance is identified by its starting date and time. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::TimePeriod',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.Named',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      derived => [
        {
          name => 'Point85.ShiftSharp.Schedule.Break',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.DayOff',
          virtualness => 'non_virtual',
          protection => 'public'
        },
        {
          name => 'Point85.ShiftSharp.Schedule.Shift',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'DeltaDays',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Duration',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetEnd',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'IsWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'SecondOfDay',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'SECONDS_PER_DAY',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'StartTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'TimePeriod',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'TimePeriod',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::TimePeriod'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'GetEnd',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get period end. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Period end time'
                    }
                  ]
                }
              ]
            },
            type => 'LocalTime',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'IsWorkingPeriod',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Check to see if this period a working period. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'True if it is'
                    }
                  ]
                }
              ]
            },
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a string value for this period. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'String'
                    }
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'StartTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'starting time of day from midnight '
                }
              ]
            },
            detailed => {},
            type => 'LocalTime'
          },
          {
            kind => 'property',
            name => 'Duration',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'length of time period '
                }
              ]
            },
            detailed => {},
            type => 'Duration'
          }
        ]
      },
      public_static_methods => {
        members => [
          {
            kind => 'function',
            name => 'SecondOfDay',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'yes',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Calculate the second in the day for this time. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'time'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Local time'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Second in day'
                    }
                  ]
                }
              ]
            },
            type => 'static int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'time',
                type => 'LocalTime'
              }
            ]
          },
          {
            kind => 'function',
            name => 'DeltaDays',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'yes',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Calculate the number of days between the start and end. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'start'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Starting date'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'end'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Ending date'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Number of days'
                    }
                  ]
                }
              ]
            },
            type => 'static long',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'start',
                type => 'LocalDate'
              },
              {
                declaration_name => 'end',
                type => 'LocalDate'
              }
            ]
          }
        ]
      },
      protected_methods => {
        members => [
          {
            kind => 'function',
            name => 'TimePeriod',
            virtualness => 'non_virtual',
            protection => 'protected',
            static => 'no',
            brief => {},
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'TimePeriod',
            virtualness => 'non_virtual',
            protection => 'protected',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Desription'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'startTime'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Starting time'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'duration'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Duration'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              },
              {
                declaration_name => 'startTime',
                type => 'LocalTime'
              },
              {
                declaration_name => 'duration',
                type => 'Duration'
              }
            ]
          }
        ]
      },
      private_static_members => {
        members => [
          {
            kind => 'variable',
            name => 'SECONDS_PER_DAY',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'yes',
            brief => {},
            detailed => {},
            type => 'const int',
            initializer => '= 24 * 60 * 60'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class TimePeriod is a named period of time with a specified duration and starting time of day. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule::WorkSchedule',
      kind => 'class',
      base => [
        {
          name => 'Point85.ShiftSharp.Schedule.Named',
          virtualness => 'non_virtual',
          protection => 'public'
        }
      ],
      inner => [
      ],
      all_members => [
        {
          name => 'BuildShiftInstances',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'CalculateNonWorkingTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'CalculateWorkingTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'CreateNonWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'CreateRotation',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'CreateShift',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'CreateTeam',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'DeleteNonWorkingPeriod',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'DeleteShift',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'DeleteTeam',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'Description',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Equals',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetAllShiftInstancesForDay',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'GetHashCode',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'GetMessage',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'GetRotationDuration',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'GetRotationWorkingTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'GetShiftInstancesForDay',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'GetShiftInstancesForTime',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'Name',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Named',
          virtualness => 'non_virtual',
          protection => 'protected',
          scope => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'NonWorkingPeriods',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'Rotations',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'Shifts',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'Teams',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'ToString',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'WorkSchedule',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'WorkSchedule',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        },
        {
          name => 'ZONE_ID',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'WorkSchedule',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'WorkSchedule',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Constructor. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Description'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              }
            ]
          },
          {
            kind => 'function',
            name => 'DeleteTeam',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Remove this team from the schedule. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'team'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Team'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'team',
                type => 'Team'
              }
            ]
          },
          {
            kind => 'function',
            name => 'DeleteNonWorkingPeriod',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Remove a non-working period from the schedule. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'period'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Non-working period'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'period',
                type => 'NonWorkingPeriod'
              }
            ]
          },
          {
            kind => 'function',
            name => 'GetShiftInstancesForDay',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the list of shift instances for the specified date that start in that date. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'day'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Date'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'List of shift instances'
                    }
                  ]
                }
              ]
            },
            type => 'List< ShiftInstance >',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'day',
                type => 'LocalDate'
              }
            ]
          },
          {
            kind => 'function',
            name => 'GetAllShiftInstancesForDay',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the list of shift instances for the specified date that start in that date or cross over from midnight the previous day. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'day'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Date'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'List of shift instances'
                    }
                  ]
                }
              ]
            },
            type => 'List< ShiftInstance >',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'day',
                type => 'LocalDate'
              }
            ]
          },
          {
            kind => 'function',
            name => 'GetShiftInstancesForTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the list of shift instances for the specified date and time of day. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'dateTime'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Date and time of day'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'List of shift instances'
                    }
                  ]
                }
              ]
            },
            type => 'List< ShiftInstance >',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'dateTime',
                type => 'LocalDateTime'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CreateTeam',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Create a team. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Description'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'rotation'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Shift rotation'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'rotationStart'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Start of rotation'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Team'
                    }
                  ]
                }
              ]
            },
            type => 'Team',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              },
              {
                declaration_name => 'rotation',
                type => 'Rotation'
              },
              {
                declaration_name => 'rotationStart',
                type => 'LocalDate'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CreateShift',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Create a shift. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Description'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'start'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Start of shift'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'duration'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Duration of shift'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Shift'
                    }
                  ]
                }
              ]
            },
            type => 'Shift',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              },
              {
                declaration_name => 'start',
                type => 'LocalTime'
              },
              {
                declaration_name => 'duration',
                type => 'Duration'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CreateRotation',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Create a rotation. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Description'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Rotation'
                    }
                  ]
                }
              ]
            },
            type => 'Rotation',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              }
            ]
          },
          {
            kind => 'function',
            name => 'DeleteShift',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Delete this shift. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'shift'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Shift'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'shift',
                type => 'Shift'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CreateNonWorkingPeriod',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Create a non-working period of time. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'name'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Name'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'description'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Description'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'startDateTime'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Starting date and time of day'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'duration'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Durtation of period'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'NonWorkingPeriod'
                    }
                  ]
                }
              ]
            },
            type => 'NonWorkingPeriod',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'name',
                type => 'string'
              },
              {
                declaration_name => 'description',
                type => 'string'
              },
              {
                declaration_name => 'startDateTime',
                type => 'LocalDateTime'
              },
              {
                declaration_name => 'duration',
                type => 'Duration'
              }
            ]
          },
          {
            kind => 'function',
            name => 'GetRotationDuration',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get total duration of rotation across all teams. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration of rotation'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'GetRotationWorkingTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Get the total working time for all team rotations. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration of working time'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'CalculateWorkingTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Calculate the scheduled working time between the specified dates and times of day.Non-working periods are removed. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'from'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Starting date and time of day'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'to'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Ending date and time of day'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration of working time'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'from',
                type => 'LocalDateTime'
              },
              {
                declaration_name => 'to',
                type => 'LocalDateTime'
              }
            ]
          },
          {
            kind => 'function',
            name => 'CalculateNonWorkingTime',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Calculate the non-working time between the specified dates and times of day. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'from'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Starting date and time of day'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'to'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Ending date and time of day'
                        }
                      ]
                    }
                  ]
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'Duration of non-working time'
                    }
                  ]
                }
              ]
            },
            type => 'Duration',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'from',
                type => 'LocalDateTime'
              },
              {
                declaration_name => 'to',
                type => 'LocalDateTime'
              }
            ]
          },
          {
            kind => 'function',
            name => 'BuildShiftInstances',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Output shift instances to a string. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  params => [
                    {
                      parameters => [
                        {
                          name => 'start'
                        }
                      ],
                      doc => [
                        {
                          type => 'text',
                          content => 'Starting date'
                        }
                      ]
                    },
                    {
                      parameters => [
                        {
                          name => 'end'
                        }
                      ],
                      doc => [
                        {
                          type => 'parbreak'
                        },
                        {
                          type => 'text',
                          content => 'Ending date'
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            type => 'string',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'start',
                type => 'LocalDate'
              },
              {
                declaration_name => 'end',
                type => 'LocalDate'
              }
            ]
          },
          {
            kind => 'function',
            name => 'ToString',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Build a string value for the work schedule. '
                }
              ]
            },
            detailed => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  return => [
                    {
                      type => 'text',
                      content => 'String'
                    }
                  ]
                }
              ]
            },
            type => 'override string',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      properties => {
        members => [
          {
            kind => 'property',
            name => 'Teams',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'list of teams '
                }
              ]
            },
            detailed => {},
            type => 'List< Team >',
            initializer => '= new List<Team>()'
          },
          {
            kind => 'property',
            name => 'Shifts',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'list of Shifts '
                }
              ]
            },
            detailed => {},
            type => 'List< Shift >',
            initializer => '= new List<Shift>()'
          },
          {
            kind => 'property',
            name => 'Rotations',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'list of Rotations '
                }
              ]
            },
            detailed => {},
            type => 'List< Rotation >',
            initializer => '= new List<Rotation>()'
          },
          {
            kind => 'property',
            name => 'NonWorkingPeriods',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'holidays and planned downtime '
                }
              ]
            },
            detailed => {},
            type => 'List< NonWorkingPeriod >',
            initializer => '= new List<NonWorkingPeriod>()'
          }
        ]
      },
      public_static_methods => {
        members => [
          {
            kind => 'function',
            name => 'GetMessage',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'yes',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'get a particular message by its key '
                }
              ]
            },
            detailed => {},
            type => 'static string',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'key',
                type => 'string'
              }
            ]
          }
        ]
      },
      private_members => {
        members => [
          {
            kind => 'variable',
            name => 'ZONE_ID',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'readonly DateTimeZone',
            initializer => '= DateTimeZone.Utc'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class WorkSchedule represents a named group of teams who collectively work one or more Shifts with off-shift periods.A work schedule can have periods of non-working time. '
          }
        ]
      },
      detailed => {}
    }
  ],
  concepts => [
  ],
  modules => [
  ],
  namespaces => [
    {
      name => 'NodaTime',
      brief => {},
      detailed => {}
    },
    {
      name => 'Point85',
      namespaces => [
        {
          name => 'Point85::ShiftSharp'
        }
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp',
      namespaces => [
        {
          name => 'Point85::ShiftSharp::Schedule'
        }
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Point85::ShiftSharp::Schedule',
      classes => [
        {
          name => 'Point85::ShiftSharp::Schedule::Break'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::DayOff'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::Named'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::NonWorkingPeriod'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::Rotation'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::RotationSegment'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::Shift'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::ShiftInstance'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::Team'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::TeamMember'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::TeamMemberException'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::TimePeriod'
        },
        {
          name => 'Point85::ShiftSharp::Schedule::WorkSchedule'
        }
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'static',
      brief => {},
      detailed => {}
    },
    {
      name => 'System',
      brief => {},
      detailed => {}
    },
    {
      name => 'System::Collections::Concurrent',
      brief => {},
      detailed => {}
    },
    {
      name => 'System::Collections::Generic',
      brief => {},
      detailed => {}
    },
    {
      name => 'System::Linq',
      brief => {},
      detailed => {}
    },
    {
      name => 'System::Runtime::InteropServices::JavaScript::JSType',
      brief => {},
      detailed => {}
    },
    {
      name => 'System::Runtime::Intrinsics::X86',
      brief => {},
      detailed => {}
    },
    {
      name => 'System::Text',
      brief => {},
      detailed => {}
    },
    {
      name => 'System::Threading::Tasks',
      brief => {},
      detailed => {}
    }
  ],
  files => [
    {
      name => 'Break.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'DayOff.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Named.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'NonWorkingPeriod.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Rotation.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'RotationSegment.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Shift.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'ShiftInstance.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Team.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'TeamMember.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'TeamMemberException.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'TimePeriod.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'WorkSchedule.cs',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    }
  ],
  groups => [
  ],
  pages => [
  ]
};
1;
